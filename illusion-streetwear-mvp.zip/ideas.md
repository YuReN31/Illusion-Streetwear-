# Direção visual — Illusion Streetwear MVP

## Abordagens consideradas

### Abordagem 1 — Concrete Editorial
Uma experiência de moda urbana com base quase monocromática, tipografia display comprimida, fotografia documental e interações rápidas de galeria. A sensação é de um lookbook digital transformado em loja.

**Probability:** 0.07

### Abordagem 2 — Soft Archive
Uma direção mais silenciosa e refinada, com off-white quente, serifas editoriais, pequenos detalhes de arquivo e transições lentas. A sensação é de catálogo de coleção e atelier contemporâneo.

**Probability:** 0.03

### Abordagem 3 — Nocturne Signal
Uma interface escura e experimental, com contrastes luminosos, tipografia técnica e navegação inspirada em sinalética urbana. A sensação é noturna, digital e mais agressiva.

**Probability:** 0.08

## Abordagem escolhida — Concrete Editorial

### Design Movement
Minimalismo editorial contemporâneo com influências de brutalismo suave, lookbook streetwear e direção de arte documental. A interface deve parecer uma galeria comprável, não um template genérico de loja.

### Core Principles
1. **Produto como matéria principal:** fotografia, silhueta, textura e escala têm prioridade sobre decoração.
2. **Contraste silencioso:** usar preto carvão, branco sujo e cinzentos frios; cor aparece principalmente nas peças e nas imagens.
3. **Tipografia como arquitetura:** headlines compactos e assertivos criam ritmo, enquanto o corpo permanece legível e funcional.
4. **Movimento editorial:** scroll, hover, carrossel e drawers revelam conteúdo com precisão, nunca como efeito gratuito.

### Color Philosophy
A estrutura deve ser sustentada por carvão quase preto `#171717`, branco osso `#F1EFEA`, cinzento concreto `#A8A7A2` e um tom de argila rosada `#D98C78` usado com moderação como assinatura da coleção. O neutro cria palco para a roupa; o acento quente liga-se às rosas do logótipo e introduz humanidade sem quebrar a austeridade urbana.

### Layout Paradigm
A composição deve evitar uma página perfeitamente centralizada. Usar um header assimétrico, hero com bloco tipográfico deslocado, grids amplos, rails horizontais e secções que alternam entre imagem dominante, texto curto e módulos de produto. O alinhamento deve parecer editorialmente intencional, com margens generosas e alguns elementos a tocar a borda do viewport.

### Signature Elements
- Moldura fina de etiqueta com microcopy de coleção, drop e temporada.
- Pequenos marcadores de carrossel e linhas de progresso inspirados em etiquetas de arquivo.
- Fotografia editorial urbana em contraste com cards de produto limpos e quase sem moldura.

### Interaction Philosophy
Cada interação deve revelar algo: um menu abre uma camada organizada, um hover mostra a segunda vista da peça, um carrossel desloca a coleção, um clique no produto abre informação essencial e o carrinho aparece sem tirar o utilizador do contexto. Feedback deve ser imediato, curto e legível.

### Animation
Usar transform e opacity, com easing `cubic-bezier(0.23, 1, 0.32, 1)`. Entradas de secção: 500–700ms, com translateY de 18–24px. Hover de card: 220–280ms, com crossfade de imagem ou scale máximo de 1.02. Drawer e modal: 280–360ms com translateX/opacity. CTA: active scale 0.97 em 140ms. Carrossel: 500–650ms com movimento suave. Nunca animar layout com width, height, margin ou padding; respeitar `prefers-reduced-motion`.

### Typography System
Display: `Space Grotesk`, com peso 700 e tracking apertado, para títulos fortes sem imitar literalmente uma fonte proprietária. Corpo: `DM Sans`, pesos 400–600, para navegação, descrição e preço. Labels e metadados: `DM Sans`, 10–12px, uppercase, tracking de 0.12–0.18em. Hero H1: clamp de 3.6rem a 8rem, line-height 0.88–0.96. Headings secundários: clamp de 2rem a 4.5rem. Corpo: 0.95–1rem com line-height 1.45–1.6.

### Brand Essence
Uma loja digital de roupa urbana para quem procura peças com presença, contraste e identidade visual; diferente porque transforma o catálogo numa experiência de galeria editorial. Personalidade: **intencional, inquieta, tátil**.

### Brand Voice
Headlines são curtas, diretas e ligeiramente provocadoras. CTAs são verbos claros. Microcopy é funcional, mas tem linguagem de coleção e movimento.

Exemplos:
- “THE PIECES MOVE DIFFERENT.”
- “ENTER THE DROP.”

### Wordmark & Logo
O logótipo fornecido com lettering branco distorcido e rosas funciona como assinatura expressiva para o hero, splash e momentos editoriais. Para o header, será preparado um tratamento mais compacto e legível: símbolo/wordmark em branco ou carvão, com versões transparentes e em placa sólida. O logótipo nunca deve ficar minúsculo; deve ter presença suficiente para ser reconhecido.

### Signature Brand Color
**Rose Signal `#D98C78`** — um rosa argila inspirado nas rosas do logótipo, usado para estados ativos, detalhes de coleção e pequenos sinais de navegação, não como preenchimento dominante.

## Regra de decisão

Antes de cada escolha visual, perguntar: **isto reforça a sensação de uma galeria editorial urbana comprável ou transforma a experiência numa loja genérica?**

## Style Decisions

- A marca deve aparecer como assinatura visual reconhecível no primeiro viewport de cada rota pública, com escala suficiente e contraste contextual.
- Grandes superfícies devem permanecer em carvão, osso e cinzas de betão; o rosa é reservado para sinais, labels, estados activos e palavras-chave.
- A fotografia deve permanecer urbana, documental, tátil e de saturação controlada, com consistência de crop e luz.
- O catálogo deve manter clareza comercial, mas ganhar momentos editoriais, metadata de coleção e interrupções visuais de lookbook.
- O backoffice deve parecer um estúdio de controlo editorial, usando linguagem de arquivo e operações, não metáforas genéricas de dashboard.
