# MVP — tarefas do ciclo atual

- [x] Gerar variações do logótipo: transparente, placa escura, placa clara e acento rosa.
- [x] Preparar ativos editoriais do hero, coleção e detalhe de textura.
- [x] Implementar design system Concrete Editorial em `client/src/index.css`.
- [x] Construir shell global com announcement bar, header, menu mobile, pesquisa e carrinho.
- [x] Construir homepage com hero editorial, manifesto, rail de produtos, coleção, lookbook e newsletter.
- [x] Implementar interação de quick add, favoritos, filtros, pesquisa e cart drawer.
- [x] Implementar página de produto com galeria, opções, quantidade e recomendações.
- [x] Garantir responsividade, estados vazios, foco de teclado e reduced motion.
- [x] Fazer verificação final por screenshots e corrigir problemas visuais críticos.
- [x] Guardar checkpoint final antes da entrega.

## Revisão 2 — escopo expandido

- [x] Ler as regras do template e auditar o MVP atual antes da refatoração.
- [x] Corrigir header, announcement bar e enquadramento transparente do logo.
- [x] Reforçar a UX/UI com barra de pesquisa global, atalho de teclado, sugestões e estados de resultado.
- [x] Adicionar alternância PT/EN com conteúdo traduzido e persistência local.
- [x] Implementar transição de entrada para links internos inspirada no vídeo 7.
- [x] Reforçar a direção visual inspirada no vídeo 2, com mais camadas, feed e movimento.
- [x] Criar página de apresentação/feed editorial com vídeo e scroll narrativo.
- [x] Criar login e conta demonstrativos com estados de sessão locais.
- [x] Criar checkout e pagamento fictício com estados de processamento, sucesso e erro.
- [x] Expandir catálogo, filtros, favoritos, pesquisa, carrinho e estados de interface, com liberdade para melhorias de descoberta e conversão.
- [x] Validar a experiência em desktop e mobile e guardar novo checkpoint.

## Revisão 3 — catálogo dinâmico e polimento

- [ ] Corrigir a escala do título hero em desktop sem perder impacto editorial.
- [ ] Criar camada de catálogo orientada por dados, com filtros, coleções e conteúdos editáveis preparados para painel.
- [ ] Reforçar microinterações de cards, pesquisa, carrinho, favoritos e navegação.
- [ ] Melhorar transições entre páginas e estados de carregamento/feedback.
- [x] Validar desktop/mobile e guardar novo checkpoint.

## Revisão 4 — logo e contraste

- [x] Auditar os contextos do logo no header, hero, footer e páginas claras.
- [x] Remover o overflow/clipping responsável pelo corte do logo.
- [x] Aplicar versões e fundos de contraste por contexto visual.
- [x] Validar o logo em desktop, mobile e sobre imagens.
- [x] Guardar nova versão depois da correção.

## Revisão 5 — fluxos, catálogo e movimento

- [x] Auditar links e ações sem destino no header, menu, footer, pesquisa e carrinho.
- [x] Fazer o menu mobile/desktop funcionar com rotas, fecho, overlay e foco.
- [x] Corrigir o sistema de contraste do logo com placa contextual, sem depender apenas de filtro preto.
- [x] Tornar ações da barra superior e do footer navegáveis ou sinalizadas como estados demonstrativos.
- [x] Expandir catálogo, filtros, coleções, wishlist, quick view e estados de descoberta.
- [x] Adicionar animações de entrada, hover, transição de página e feedback de ações.
- [x] Validar os fluxos em desktop/mobile e guardar novo checkpoint.

## Revisão 6 — backoffice funcional

- [x] Criar navegação interna por módulos sem ações silenciosas.
- [x] Persistir dados do painel em localStorage com modelo versionado.
- [x] Implementar CRUD local de produtos, variantes, preço e stock.
- [x] Implementar gestão de coleções e conteúdo editorial da homepage.
- [x] Implementar listagens demonstrativas de pedidos e clientes.
- [x] Implementar cupões, definições da loja e estado operacional.
- [x] Adicionar formulários, validações, confirmação de eliminação e toasts.
- [x] Validar desktop/mobile e guardar novo checkpoint.

## Revisão 7 — glow up integral

- [x] Reforçar a composição do hero com camadas, ritmo e assinatura visual.
- [x] Melhorar a tipografia responsiva e a hierarquia de secções.
- [x] Criar motion system mais expressivo para entradas, hover, menu, busca e transições.
- [x] Elevar cartões de produto, quick add, favoritos, carrinho e estados de feedback.
- [x] Tornar o feed editorial mais imersivo e coerente com os vídeos.
- [x] Refinar o backoffice para manter a mesma qualidade visual do storefront.
- [x] Validar desktop/mobile e guardar checkpoint final.

## Revisão 8 — refinamento de autoria

- [x] Tornar o logótipo distorcido mais presente no primeiro viewport das rotas públicas.
- [x] Harmonizar imagens com crop, contraste e saturação documental urbana.
- [x] Introduzir agrupamentos editoriais e metadata no catálogo.
- [x] Substituir copy genérica por linguagem de drop e movimento.
- [x] Reforçar a linguagem de arquivo no backoffice.
- [x] Validar a revisão sem abrir novo ciclo de style review.





