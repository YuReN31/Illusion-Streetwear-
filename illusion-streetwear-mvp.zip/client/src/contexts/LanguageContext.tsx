/* Concrete Editorial: internacionalização leve para o MVP; conteúdo PT/EN centralizado e troca instantânea sem recarregar a experiência. */
import { createContext, useContext, useMemo, useState, type ReactNode } from "react";

export type Locale = "pt" | "en";
type Dictionary = Record<string, string>;
const dictionaries: Record<Locale, Dictionary> = {
  pt: {
    menu: "Menu", shop: "Loja", collection: "Coleção", journal: "Diário", search: "Pesquisar", bag: "Sacola", all: "Todas as peças", newDrop: "Novo drop", shopDrop: "Ver o drop", explore: "Explorar peças", newArrivals: "Novidades", viewAll: "Ver tudo", addToBag: "Adicionar à sacola", yourBag: "A sua sacola", subtotal: "Subtotal", checkout: "Continuar para pagamento", emptyBag: "A sacola está vazia.", searchPlaceholder: "Pesquisar peças, coleções...", close: "Fechar", account: "Conta", signIn: "Entrar", story: "Manifesto", feed: "Feed", language: "Idioma", email: "Endereço de email", subscribe: "Subscrever", nothingFound: "Nenhum sinal encontrado", reset: "Limpar filtros", accountTitle: "O seu espaço.", accountIntro: "Guarde favoritos, acompanhe pedidos e mantenha o seu sinal perto.", demoNote: "Modo demonstração — sem dados reais.", continue: "Continuar", signOut: "Sair", payment: "Pagamento", payNow: "Pagar agora", orderReady: "Pedido preparado.", demoPayment: "Pagamento fictício", back: "Voltar", readMore: "Ler mais", storyTitle: "O movimento é a mensagem.", storyIntro: "Uma sequência de imagens, matéria e cidade. Deslize pelo universo da coleção.", filter: "Filtrar", sort: "Ordenar", featured: "Destaques", priceLow: "Preço: menor", priceHigh: "Preço: maior",
  },
  en: {
    menu: "Menu", shop: "Shop", collection: "Collection", journal: "Journal", search: "Search", bag: "Bag", all: "All pieces", newDrop: "New drop", shopDrop: "Shop the drop", explore: "Explore pieces", newArrivals: "New arrivals", viewAll: "View all", addToBag: "Add to bag", yourBag: "Your bag", subtotal: "Subtotal", checkout: "Proceed to checkout", emptyBag: "Your bag is empty.", searchPlaceholder: "Search pieces, collections...", close: "Close", account: "Account", signIn: "Sign in", story: "Manifesto", feed: "Feed", language: "Language", email: "Email address", subscribe: "Subscribe", nothingFound: "No signal found", reset: "Reset filters", accountTitle: "Your space.", accountIntro: "Save favourites, follow orders and keep your signal close.", demoNote: "Demo mode — no real data.", continue: "Continue", signOut: "Sign out", payment: "Payment", payNow: "Pay now", orderReady: "Order ready.", demoPayment: "Demo payment", back: "Back", readMore: "Read more", storyTitle: "Movement is the message.", storyIntro: "A sequence of image, matter and city. Scroll through the collection universe.", filter: "Filter", sort: "Sort", featured: "Featured", priceLow: "Price: low", priceHigh: "Price: high",
  },
};

const LanguageContext = createContext<{ locale: Locale; setLocale: (locale: Locale) => void; t: (key: string) => string } | null>(null);
export function LanguageProvider({ children }: { children: ReactNode }) {
  const [locale, setLocale] = useState<Locale>(() => (localStorage.getItem("illusion-locale") as Locale) || "pt");
  const changeLocale = (value: Locale) => { setLocale(value); localStorage.setItem("illusion-locale", value); };
  const value = useMemo(() => ({ locale, setLocale: changeLocale, t: (key: string) => dictionaries[locale][key] ?? key }), [locale]);
  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}
export function useLanguage() { const context = useContext(LanguageContext); if (!context) throw new Error("useLanguage must be used inside LanguageProvider"); return context; }
