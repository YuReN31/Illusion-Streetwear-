/* Concrete Editorial: conta demonstrativa local para testar fluxo de login, perfil e estados de sessão antes da integração real. */
import { createContext, useContext, useMemo, useState, type ReactNode } from "react";

type DemoUser = { name: string; email: string };
const AuthContext = createContext<{ user: DemoUser | null; login: (email: string, name?: string) => void; logout: () => void } | null>(null);
export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<DemoUser | null>(() => { const saved = localStorage.getItem("illusion-user"); return saved ? JSON.parse(saved) : null; });
  const login = (email: string, name = email.split("@")[0]) => { const next = { name, email }; setUser(next); localStorage.setItem("illusion-user", JSON.stringify(next)); };
  const logout = () => { setUser(null); localStorage.removeItem("illusion-user"); };
  const value = useMemo(() => ({ user, login, logout }), [user]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
export function useAuth() { const context = useContext(AuthContext); if (!context) throw new Error("useAuth must be used inside AuthProvider"); return context; }
