/* Concrete Editorial: conta em modo demo com formulário editorial, sessão local e claro aviso de que não existe autenticação real nesta fase. */
import { useState } from "react";
import { ArrowUpRight, LogOut } from "lucide-react";
import { Link } from "wouter";
import { Footer, Header, SectionLabel, CartDrawer, BackToTop } from "@/components/StorefrontShell";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";

export default function Account() {
  const { user, login, logout } = useAuth();
  const { locale, t } = useLanguage();
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  return <div className="storefront-page light-page"><Header /><CartDrawer /><main className="account-page page-pad"><div className="account-grid"><div className="account-title"><SectionLabel index="01">{t("account")}</SectionLabel><h1>{user ? <>{t("accountTitle")}<br />{user.name}.</> : <>{t("accountTitle")}<br /><i>{locale === "pt" ? "Fica perto." : "Stay close."}</i></>}</h1></div><div className="account-card">{user ? <div className="account-logged"><span className="account-avatar">{user.name.slice(0, 1).toUpperCase()}</span><span className="section-kicker">{t("demoNote")}</span><h2>{user.name}</h2><p>{user.email}</p><div className="account-stats"><div><strong>00</strong><span>Orders</span></div><div><strong>02</strong><span>Saved</span></div><div><strong>01</strong><span>Address</span></div></div><button className="outline-button" onClick={logout}><LogOut size={15} /> {t("signOut")}</button></div> : <form className="account-form" onSubmit={(event) => { event.preventDefault(); if (email) login(email, name || undefined); }}><span className="section-kicker">{t("demoNote")}</span><p>{t("accountIntro")}</p><label>Name<input value={name} onChange={(event) => setName(event.target.value)} placeholder="Your name" /></label><label>{t("email")}<input type="email" required value={email} onChange={(event) => setEmail(event.target.value)} placeholder="you@email.com" /></label><button className="dark-button full-button" type="submit">{t("continue")} <ArrowUpRight size={16} /></button><small>Ao continuar, está apenas a testar a experiência visual. A autenticação real será adicionada numa fase posterior.</small></form>}</div></div><section className="account-bottom"><span className="section-kicker">New here?</span><Link href="/shop" className="text-link">{t("explore")} <ArrowUpRight size={16} /></Link></section></main><Footer /><BackToTop /></div>;
}
