/* Concrete Editorial: página de produto como ficha de lookbook; galeria tátil, informação curta e ação de compra persistente. */
import { useState } from "react";
import { ArrowDown, ArrowUpRight, ChevronLeft, ChevronRight, Heart, Minus, Plus } from "lucide-react";
import { Link, useRoute } from "wouter";
import { CartDrawer, Footer, Header, ProductCard, SectionLabel, BackToTop } from "@/components/StorefrontShell";
import { formatPrice, products } from "@/lib/storeData";
import { useCart } from "@/contexts/CartContext";
import { useLanguage } from "@/contexts/LanguageContext";

const collectionImage = "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1600&q=85";
const detailImage = "https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&w=1200&q=85";

export default function Product() {
  const { locale, t } = useLanguage();
  const pt = locale === "pt";
  const [, params] = useRoute("/product/:slug");
  const product = products.find((item) => item.slug === params?.slug) ?? products[0];
  const [selectedSize, setSelectedSize] = useState(product.sizes[2] ?? product.sizes[0]);
  const [quantity, setQuantity] = useState(1);
  const [activeImage, setActiveImage] = useState(0);
  const [saved, setSaved] = useState(false);
  const { addToCart } = useCart();
  const gallery = [product.image, collectionImage, detailImage];
  const related = products.filter((item) => item.slug !== product.slug).slice(0, 3);

  return (
    <div className="storefront-page light-page">
      <Header />
      <CartDrawer />
      <main>
        <div className="product-breadcrumb page-pad"><Link href="/shop">{t("shop")}</Link><span>/</span><span>{product.category}</span><span>/</span><span>{product.name}</span></div>
        <section className="product-detail page-pad">
          <div className="product-gallery"><div className="gallery-main"><img src={gallery[activeImage]} alt={activeImage === 0 ? product.alt : `${product.name} editorial view ${activeImage + 1}`} /><div className="gallery-controls"><button onClick={() => setActiveImage((activeImage + gallery.length - 1) % gallery.length)} aria-label="Imagem anterior"><ChevronLeft size={17} /></button><span>0{activeImage + 1} / 0{gallery.length}</span><button onClick={() => setActiveImage((activeImage + 1) % gallery.length)} aria-label="Imagem seguinte"><ChevronRight size={17} /></button></div></div><div className="gallery-thumbs">{gallery.map((image, index) => <button className={activeImage === index ? "active" : ""} key={image} onClick={() => setActiveImage(index)} aria-label={`Ver imagem ${index + 1}`}><img src={image} alt="" /></button>)}</div></div>
          <div className="product-info"><div className="product-info-top"><SectionLabel index="01">{product.category}</SectionLabel><button className={`product-save ${saved ? "saved" : ""}`} onClick={() => setSaved(!saved)} aria-label={saved ? "Remover dos favoritos" : "Guardar nos favoritos"}><Heart size={19} fill={saved ? "currentColor" : "none"} /></button></div><h1>{product.name}</h1><div className="product-price">{formatPrice(product.price)}</div><p className="product-description">{product.description}</p><div className="product-divider" /><div className="option-block"><div className="option-heading"><span>{pt ? "Tamanho" : "Size"}</span><a href="#size-guide">{pt ? "Guia de tamanhos" : "Size guide"} <ArrowUpRight size={13} /></a></div><div className="size-options">{product.sizes.map((size) => <button className={selectedSize === size ? "selected" : ""} onClick={() => setSelectedSize(size)} key={size}>{size}</button>)}</div></div><div className="product-buy-row"><div className="quantity-control large"><button onClick={() => setQuantity(Math.max(1, quantity - 1))} aria-label="Diminuir quantidade"><Minus size={14} /></button><span>{String(quantity).padStart(2, "0")}</span><button onClick={() => setQuantity(quantity + 1)} aria-label="Aumentar quantidade"><Plus size={14} /></button></div><button className="dark-button add-button" onClick={() => { for (let index = 0; index < quantity; index += 1) addToCart(product, selectedSize); }}>{t("addToBag")} <ArrowUpRight size={17} /></button></div><div className="product-notes"><details open><summary>{pt ? "Detalhes" : "Details"} <Plus size={15} /></summary><p>{product.material}. Corte relaxado. Feito para ser usado em camadas, com acabamento que ganha carácter com o tempo.</p></details><details><summary>{pt ? "Entrega e devoluções" : "Delivery & returns"} <Plus size={15} /></summary><p>Entrega estimada em 2–5 dias úteis. Devoluções aceites dentro de 14 dias em peças não usadas.</p></details><details><summary>{pt ? "Estudo de matéria" : "Material study"} <Plus size={15} /></summary><p>Textura, peso e construção pensados para a cidade em movimento.</p></details></div></div>
        </section>
        <section className="product-story"><div className="product-story-copy"><SectionLabel index="02">{pt ? "Um olhar mais perto" : "A closer look"}</SectionLabel><h2>{pt ? <>Feito para<br /><i>mover.</i></> : <>Built to<br /><i>move.</i></>}</h2><p>{pt ? "Uma peça não é só o que se vê no primeiro frame. É o peso, a queda, o som do fecho, a forma como acompanha o corpo." : "A piece is more than what appears in the first frame. It is the weight, the fall, the sound of the zip, the way it follows the body."}</p><a className="text-link" href="#details">{pt ? "Ver os detalhes" : "See the details"} <ArrowUpRight size={16} /></a></div><div className="product-story-image"><img src={detailImage} alt="Detalhe da matéria de uma peça de roupa" /><span>Material study / 01</span></div></section>
        <section className="related-section page-pad"><div className="section-heading-row"><div><SectionLabel index="03">{pt ? "Também pode gostar" : "You may also like"}</SectionLabel><h2>{pt ? <>Mantém o<br /><i>sinal.</i></> : <>Keep the<br /><i>signal.</i></>}</h2></div><Link href="/shop" className="outline-button">Shop all <ArrowUpRight size={16} /></Link></div><div className="product-rail">{related.map((item, index) => <ProductCard product={item} index={index} key={item.slug} />)}</div></section>
      </main>
      <Footer />
      <BackToTop />
    </div>
  );
}
